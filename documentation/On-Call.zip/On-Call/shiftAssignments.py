shiftAssignments = {}
